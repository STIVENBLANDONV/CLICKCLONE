import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validation = insertContactSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          error: "Validation failed",
          details: fromZodError(validation.error).toString()
        });
      }

      const contact = await storage.createContact(validation.data);
      
      res.status(201).json({
        success: true,
        message: "Contact form submitted successfully",
        id: contact.id
      });
    } catch (error) {
      console.error("Error submitting contact form:", error);
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  // Get all contacts endpoint (for admin/management purposes)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({
        error: "Internal server error"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
