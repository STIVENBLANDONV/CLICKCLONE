export default function WhatsappFloat() {
  const whatsappUrl = "https://wa.me/573114769904?text=Bienvenidos%20a%20Virtual%20Click,%20escr%C3%ADbenos%20tu%20pregunta%20y%20en%20breve%20te%20responderemos.";

  return (
    <a 
      href={whatsappUrl}
      target="_blank" 
      rel="noopener noreferrer"
      className="whatsapp-float fixed bottom-5 right-5 z-50"
      data-testid="button-whatsapp-float"
    >
      <div className="w-14 h-14 bg-whatsapp-green rounded-full flex items-center justify-center shadow-lg hover:bg-whatsapp-green-hover transition-colors">
        <i className="fab fa-whatsapp text-white text-2xl"></i>
      </div>
    </a>
  );
}
