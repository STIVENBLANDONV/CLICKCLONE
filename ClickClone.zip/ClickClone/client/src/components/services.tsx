export default function Services() {
  const services = [
    {
      icon: "fas fa-code",
      title: "Desarrollo Web",
      description: "Sitios web modernos, responsivos y optimizados para brindar la mejor experiencia de usuario",
      features: ["Diseño responsivo", "Optimización SEO", "Velocidad optimizada"]
    },
    {
      icon: "fas fa-bullhorn",
      title: "Marketing Digital",
      description: "Estrategias de marketing digital para aumentar tu visibilidad y generar más conversiones",
      features: ["Redes sociales", "Google Ads", "Email marketing"]
    },
    {
      icon: "fas fa-shopping-cart",
      title: "E-commerce",
      description: "Tiendas online profesionales con sistemas de pago seguros y gestión de inventario",
      features: ["Pagos seguros", "Gestión de productos", "Analytics integrados"]
    },
    {
      icon: "fas fa-search",
      title: "SEO",
      description: "Optimización para motores de búsqueda para mejorar tu posicionamiento en Google",
      features: ["Análisis de keywords", "Optimización técnica", "Link building"]
    },
    {
      icon: "fas fa-palette",
      title: "Branding",
      description: "Creación de identidad visual que refleje los valores y personalidad de tu marca",
      features: ["Diseño de logos", "Manual de marca", "Materiales gráficos"]
    },
    {
      icon: "fas fa-tools",
      title: "Mantenimiento",
      description: "Soporte técnico continuo para mantener tu sitio web actualizado y seguro",
      features: ["Actualizaciones", "Backups automáticos", "Soporte 24/7"]
    }
  ];

  return (
    <section id="servicios" className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Nuestros Servicios</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ofrecemos soluciones digitales completas para impulsar tu presencia online y hacer crecer tu negocio
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="service-card bg-card p-8 rounded-xl shadow-sm hover:shadow-md transition-all"
              data-testid={`service-card-${index}`}
            >
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                <i className={`${service.icon} text-primary text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4" data-testid={`service-title-${index}`}>
                {service.title}
              </h3>
              <p className="text-muted-foreground mb-6" data-testid={`service-description-${index}`}>
                {service.description}
              </p>
              <ul className="text-sm text-muted-foreground space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} data-testid={`service-feature-${index}-${featureIndex}`}>
                    <i className="fas fa-check text-primary mr-2"></i>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
