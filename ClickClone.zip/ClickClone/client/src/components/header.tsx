import { useState, useEffect } from "react";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      setScrolled(scrollTop > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    // Close mobile menu first to ensure immediate feedback
    setMobileMenuOpen(false);
    
    // Small delay to ensure state update before scrolling
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  return (
    <>
      <header className={`bg-card sticky top-0 z-50 transition-shadow ${scrolled ? 'shadow-lg' : 'shadow-sm'}`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <i className="fas fa-mouse-pointer text-primary-foreground text-xl"></i>
            </div>
            <span className="text-xl font-bold text-foreground">Virtual Click</span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection('inicio')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-inicio"
            >
              Inicio
            </button>
            <button 
              onClick={() => scrollToSection('servicios')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-servicios"
            >
              Servicios
            </button>
            <button 
              onClick={() => scrollToSection('portafolio')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-portafolio"
            >
              Portafolio
            </button>
            <button 
              onClick={() => scrollToSection('contacto')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-contacto"
            >
              Contacto
            </button>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-foreground"
            onClick={() => setMobileMenuOpen(true)}
            data-testid="button-mobile-menu"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <div 
        className={`mobile-menu md:hidden fixed top-0 right-0 h-full w-64 bg-card shadow-lg z-50 ${mobileMenuOpen ? 'open' : ''}`}
        data-testid="mobile-menu"
      >
        <div className="p-4">
          <button 
            className="float-right text-foreground"
            onClick={() => setMobileMenuOpen(false)}
            data-testid="button-close-menu"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
          <div className="clear-both pt-8">
            <nav className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('inicio')}
                className="text-muted-foreground hover:text-primary transition-colors py-2 text-left"
                data-testid="mobile-nav-inicio"
              >
                Inicio
              </button>
              <button 
                onClick={() => scrollToSection('servicios')}
                className="text-muted-foreground hover:text-primary transition-colors py-2 text-left"
                data-testid="mobile-nav-servicios"
              >
                Servicios
              </button>
              <button 
                onClick={() => scrollToSection('portafolio')}
                className="text-muted-foreground hover:text-primary transition-colors py-2 text-left"
                data-testid="mobile-nav-portafolio"
              >
                Portafolio
              </button>
              <button 
                onClick={() => scrollToSection('contacto')}
                className="text-muted-foreground hover:text-primary transition-colors py-2 text-left"
                data-testid="mobile-nav-contacto"
              >
                Contacto
              </button>
            </nav>
          </div>
        </div>
      </div>

      {/* Mobile Menu Backdrop */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={() => setMobileMenuOpen(false)}
          data-testid="mobile-menu-backdrop"
        />
      )}
    </>
  );
}
