export default function Portfolio() {
  const portfolioItems = [
    {
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "E-commerce moderno con displays de productos limpios",
      title: "Tienda Online Fashion",
      description: "E-commerce completo con sistema de pagos y gestión de inventario",
      tags: ["E-commerce", "React", "Stripe"]
    },
    {
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "Sitio web profesional de restaurante con fotografía elegante de comida",
      title: "Restaurante Gourmet",
      description: "Sitio web elegante con reservas online y menú digital",
      tags: ["Web Design", "WordPress", "Reservas"]
    },
    {
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "Sitio web corporativo de finanzas con sala de reuniones profesional",
      title: "Consultora Financiera",
      description: "Portal corporativo con dashboard personalizado",
      tags: ["Corporate", "Dashboard", "Angular"]
    },
    {
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "Interfaz de aplicación de salud y fitness en dispositivo móvil",
      title: "App Fitness",
      description: "Aplicación móvil para seguimiento de ejercicios y nutrición",
      tags: ["Mobile App", "React Native", "Health"]
    },
    {
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "Sitio web inmobiliario con listados modernos de propiedades",
      title: "Portal Inmobiliario",
      description: "Plataforma de búsqueda y listado de propiedades",
      tags: ["Real Estate", "Vue.js", "Maps API"]
    },
    {
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      alt: "Plataforma educativa con estudiantes usando laptops en aula moderna",
      title: "Plataforma Educativa",
      description: "LMS completo con cursos online y certificaciones",
      tags: ["Education", "LMS", "Django"]
    }
  ];

  return (
    <section id="portafolio" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Nuestro Portafolio</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Algunos de los proyectos exitosos que hemos desarrollado para nuestros clientes
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <div 
              key={index}
              className="portfolio-item bg-card rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all"
              data-testid={`portfolio-item-${index}`}
            >
              <img 
                src={item.image} 
                alt={item.alt}
                className="w-full h-48 object-cover"
                data-testid={`portfolio-image-${index}`}
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2" data-testid={`portfolio-title-${index}`}>
                  {item.title}
                </h3>
                <p className="text-muted-foreground mb-4" data-testid={`portfolio-description-${index}`}>
                  {item.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex}
                      className="bg-primary/10 text-primary text-xs px-2 py-1 rounded"
                      data-testid={`portfolio-tag-${index}-${tagIndex}`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <button 
            className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            data-testid="button-ver-mas-proyectos"
          >
            Ver Más Proyectos
          </button>
        </div>
      </div>
    </section>
  );
}
