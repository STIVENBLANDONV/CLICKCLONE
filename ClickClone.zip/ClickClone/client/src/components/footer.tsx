export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-mouse-pointer text-primary-foreground text-xl"></i>
              </div>
              <span className="text-xl font-bold text-foreground">Virtual Click</span>
            </div>
            <p className="text-muted-foreground mb-4 max-w-md" data-testid="text-company-description">
              Studio Virtual Click es tu socio estratégico en el mundo digital. Creamos experiencias web excepcionales y estrategias de marketing que impulsan el crecimiento de tu negocio.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-linkedin"
              >
                <i className="fab fa-linkedin-in"></i>
              </a>
              <a 
                href="#" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-link-twitter"
              >
                <i className="fab fa-twitter"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4">Servicios</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('servicios')}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-nav-desarrollo-web"
                >
                  Desarrollo Web
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicios')}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-nav-marketing-digital"
                >
                  Marketing Digital
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicios')}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-nav-ecommerce"
                >
                  E-commerce
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicios')}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-nav-seo"
                >
                  SEO
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicios')}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-nav-branding"
                >
                  Branding
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4">Contacto</h4>
            <ul className="space-y-2">
              <li className="text-muted-foreground" data-testid="footer-text-phone">+57 311 476 9904</li>
              <li className="text-muted-foreground" data-testid="footer-text-email">info@studiovirtualclick.com</li>
              <li className="text-muted-foreground" data-testid="footer-text-location">Colombia</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border pt-8 mt-8 text-center">
          <p className="text-muted-foreground" data-testid="text-copyright">
            © 2024 Studio Virtual Click. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
