export default function Hero() {
  const scrollToPortfolio = () => {
    const element = document.getElementById('portafolio');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToContact = () => {
    const element = document.getElementById('contacto');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="inicio" className="hero-gradient py-20 lg:py-32">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
          Transformamos tus ideas en
          <span className="block">experiencias digitales</span>
        </h1>
        <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
          Desarrollo web profesional y marketing digital estratégico para hacer crecer tu negocio en el mundo digital
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={scrollToPortfolio}
            className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            data-testid="button-ver-proyectos"
          >
            Ver Nuestros Proyectos
          </button>
          <button 
            onClick={scrollToContact}
            className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors"
            data-testid="button-solicitar-cotizacion"
          >
            Solicitar Cotización
          </button>
        </div>
      </div>
    </section>
  );
}
